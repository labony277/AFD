<?php include 'header.php'; ?>


<style>
    .course:hover {
        background-color: #265D3B;
    }
</style>
<section class="space-ptb course-list bg-light">
    <div class="container">
        <div class="row justify-content-center ">


            <div class="course col-md-8 text-center">
                <div class="no-gutters box-shadow mb-4">

                    <div class="course-info p-0 h-100">
                        <div class="px-4 pt-4">
                            <div class="course-title">
                                <a href="#"><strong>Principal&nbsp;Staff Officer's office</strong></a>
                            </div>
                            <p>
                                Appointment: Private Secretary to Principal&nbsp;Staff Officer<br>
                                Rank: Major<br>
                                Name: <span><span><span>Md Al-Amin, SUP, BIR</span></span></span><br>
                                Telephone: 983-4322&nbsp;<br>
                                Mobile: 0176901-4322<br>
                                E-mail: ps_pso@afd.gov.bd , ps2psoafd@gmail.com</p>
                        </div>

                    </div>

                </div>

            </div>


            <div class="course col-md-8 text-center">
                <div class="no-gutters box-shadow mb-4">

                    <div class="course-info p-0 h-100">
                        <div class="px-4 pt-4">
                            <div class="course-title">
                                <a href="#"><strong>Principal&nbsp;Staff Officer's office</strong></a>
                            </div>
                            <p>
                                Appointment: Private Secretary to Principal&nbsp;Staff Officer<br>
                                Rank: Major<br>
                                Name: <span><span><span>Md Al-Amin, SUP, BIR</span></span></span><br>
                                Telephone: 983-4322&nbsp;<br>
                                Mobile: 0176901-4322<br>
                                E-mail: ps_pso@afd.gov.bd , ps2psoafd@gmail.com</p>
                        </div>

                    </div>

                </div>

            </div>


            <div class="course col-md-8 text-center">
                <div class="no-gutters box-shadow mb-4">

                    <div class="course-info p-0 h-100">
                        <div class="px-4 pt-4">
                            <div class="course-title">
                                <a href="#"><strong>Principal&nbsp;Staff Officer's office</strong></a>
                            </div>
                            <p>
                                Appointment: Private Secretary to Principal&nbsp;Staff Officer<br>
                                Rank: Major<br>
                                Name: <span><span><span>Md Al-Amin, SUP, BIR</span></span></span><br>
                                Telephone: 983-4322&nbsp;<br>
                                Mobile: 0176901-4322<br>
                                E-mail: ps_pso@afd.gov.bd , ps2psoafd@gmail.com</p>
                        </div>

                    </div>

                </div>

            </div>


            <div class="course col-md-8 text-center">
                <div class="no-gutters box-shadow mb-4">

                    <div class="course-info p-0 h-100">
                        <div class="px-4 pt-4">
                            <div class="course-title">
                                <a href="#"><strong>Principal&nbsp;Staff Officer's office</strong></a>
                            </div>
                            <p>
                                Appointment: Private Secretary to Principal&nbsp;Staff Officer<br>
                                Rank: Major<br>
                                Name: <span><span><span>Md Al-Amin, SUP, BIR</span></span></span><br>
                                Telephone: 983-4322&nbsp;<br>
                                Mobile: 0176901-4322<br>
                                E-mail: ps_pso@afd.gov.bd , ps2psoafd@gmail.com</p>
                        </div>

                    </div>

                </div>

            </div>


            <div class="course col-md-8 text-center">
                <div class="no-gutters box-shadow mb-4">

                    <div class="course-info p-0 h-100">
                        <div class="px-4 pt-4">
                            <div class="course-title">
                                <a href="#"><strong>Principal&nbsp;Staff Officer's office</strong></a>
                            </div>
                            <p>
                                Appointment: Private Secretary to Principal&nbsp;Staff Officer<br>
                                Rank: Major<br>
                                Name: <span><span><span>Md Al-Amin, SUP, BIR</span></span></span><br>
                                Telephone: 983-4322&nbsp;<br>
                                Mobile: 0176901-4322<br>
                                E-mail: ps_pso@afd.gov.bd , ps2psoafd@gmail.com</p>
                        </div>

                    </div>

                </div>

            </div>


            <div class="course col-md-8 text-center">
                <div class="no-gutters box-shadow mb-4">

                    <div class="course-info p-0 h-100">
                        <div class="px-4 pt-4">
                            <div class="course-title">
                                <a href="#"><strong>Principal&nbsp;Staff Officer's office</strong></a>
                            </div>
                            <p>
                                Appointment: Private Secretary to Principal&nbsp;Staff Officer<br>
                                Rank: Major<br>
                                Name: <span><span><span>Md Al-Amin, SUP, BIR</span></span></span><br>
                                Telephone: 983-4322&nbsp;<br>
                                Mobile: 0176901-4322<br>
                                E-mail: ps_pso@afd.gov.bd , ps2psoafd@gmail.com</p>
                        </div>

                    </div>

                </div>

            </div>


            <div class="course col-md-8 text-center">
                <div class="no-gutters box-shadow mb-4">

                    <div class="course-info p-0 h-100">
                        <div class="px-4 pt-4">
                            <div class="course-title">
                                <a href="#"><strong>Principal&nbsp;Staff Officer's office</strong></a>
                            </div>
                            <p>
                                Appointment: Private Secretary to Principal&nbsp;Staff Officer<br>
                                Rank: Major<br>
                                Name: <span><span><span>Md Al-Amin, SUP, BIR</span></span></span><br>
                                Telephone: 983-4322&nbsp;<br>
                                Mobile: 0176901-4322<br>
                                E-mail: ps_pso@afd.gov.bd , ps2psoafd@gmail.com</p>
                        </div>

                    </div>

                </div>

            </div>

            <div class="course col-md-8 text-center">
                <div class="no-gutters box-shadow mb-4">

                    <div class="course-info p-0 h-100">
                        <div class="px-4 pt-4">
                            <div class="course-title">
                                <a href="#"><strong>Principal&nbsp;Staff Officer's office</strong></a>
                            </div>
                            <p>
                                Appointment: Private Secretary to Principal&nbsp;Staff Officer<br>
                                Rank: Major<br>
                                Name: <span><span><span>Md Al-Amin, SUP, BIR</span></span></span><br>
                                Telephone: 983-4322&nbsp;<br>
                                Mobile: 0176901-4322<br>
                                E-mail: ps_pso@afd.gov.bd , ps2psoafd@gmail.com</p>
                        </div>

                    </div>

                </div>

            </div>

            <div class="course col-md-8 text-center">
                <div class="no-gutters box-shadow mb-4">

                    <div class="course-info p-0 h-100">
                        <div class="px-4 pt-4">
                            <div class="course-title">
                                <a href="#"><strong>Principal&nbsp;Staff Officer's office</strong></a>
                            </div>
                            <p>
                                Appointment: Private Secretary to Principal&nbsp;Staff Officer<br>
                                Rank: Major<br>
                                Name: <span><span><span>Md Al-Amin, SUP, BIR</span></span></span><br>
                                Telephone: 983-4322&nbsp;<br>
                                Mobile: 0176901-4322<br>
                                E-mail: ps_pso@afd.gov.bd , ps2psoafd@gmail.com</p>
                        </div>

                    </div>

                </div>

            </div>

            <div class="course col-md-8 text-center">
                <div class="no-gutters box-shadow mb-4">

                    <div class="course-info p-0 h-100">
                        <div class="px-4 pt-4">
                            <div class="course-title">
                                <a href="#"><strong>Principal&nbsp;Staff Officer's office</strong></a>
                            </div>
                            <p>
                                Appointment: Private Secretary to Principal&nbsp;Staff Officer<br>
                                Rank: Major<br>
                                Name: <span><span><span>Md Al-Amin, SUP, BIR</span></span></span><br>
                                Telephone: 983-4322&nbsp;<br>
                                Mobile: 0176901-4322<br>
                                E-mail: ps_pso@afd.gov.bd , ps2psoafd@gmail.com</p>
                        </div>

                    </div>

                </div>

            </div>

            <div class="course col-md-8 text-center">
                <div class="no-gutters box-shadow mb-4">

                    <div class="course-info p-0 h-100">
                        <div class="px-4 pt-4">
                            <div class="course-title">
                                <a href="#"><strong>Principal&nbsp;Staff Officer's office</strong></a>
                            </div>
                            <p>
                                Appointment: Private Secretary to Principal&nbsp;Staff Officer<br>
                                Rank: Major<br>
                                Name: <span><span><span>Md Al-Amin, SUP, BIR</span></span></span><br>
                                Telephone: 983-4322&nbsp;<br>
                                Mobile: 0176901-4322<br>
                                E-mail: ps_pso@afd.gov.bd , ps2psoafd@gmail.com</p>
                        </div>

                    </div>

                </div>

            </div>

        </div>
    </div>
    </div>
</section>


<?php include 'footer.php'; ?>
